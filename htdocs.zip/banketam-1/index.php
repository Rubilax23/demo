<?php
require_once 'db.php';
if (isset($_SESSION['user_id'])) {
    echo "works";
} else {
    header('Location: login.php');
}
exit;
