<?php
session_start();

$conn = mysqli_connect('localhost', 'root', 'root', 'banketam');
if (!$conn) {
    die('Ошибка подключения к базе данных');
}
mysqli_set_charset($conn, 'utf8mb4');
