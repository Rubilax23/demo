<?php
require_once 'db.php';
if (isset($_SESSION['user_id'])) { header('Location: cabinet.php'); exit; }

$errors = [];
$old = ['login' => '', 'fio' => '', 'phone' => '', 'email' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login = trim($_POST['login']);
    $password = $_POST['password'];
    $fio = trim($_POST['fio']);
    $phone = trim($_POST['phone']);
    $email = trim($_POST['email']);
    $old = ['login' => $login, 'fio' => $fio, 'phone' => $phone, 'email' => $email];

    if ($login === '' || $password === '' || $fio === '' || $phone === '' || $email === '') {
        $errors['common'] = 'Заполните все поля';
    }
    if (!preg_match('/^[A-Za-z0-9]{6,}$/', $login)) {
        $errors['login'] = 'Логин: латинские буквы и цифры, минимум 6 символов';
    }
    if (strlen($password) < 8) {
        $errors['password'] = 'Пароль должен содержать минимум 8 символов';
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = 'Введите корректный e-mail';
    }
    if (!isset($errors['login'])) {
        $stmt = mysqli_prepare($conn, 'SELECT id FROM users WHERE login = ?');
        mysqli_stmt_bind_param($stmt, 's', $login);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_store_result($stmt);
        if (mysqli_stmt_num_rows($stmt) > 0) {
            $errors['login'] = 'Такой логин уже существует';
        }
        mysqli_stmt_close($stmt);
    }

    if (!$errors) {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = mysqli_prepare($conn, 'INSERT INTO users (login, password, fio, phone, email) VALUES (?, ?, ?, ?, ?)');
        mysqli_stmt_bind_param($stmt, 'sssss', $login, $hash, $fio, $phone, $email);
        mysqli_stmt_execute($stmt);
        $_SESSION['user_id'] = mysqli_insert_id($conn);
        $_SESSION['login'] = $login;
        header('Location: cabinet.php');
        exit;
    }
}

$narrow = true;
include 'header.php';
?>
<h1 class="title">Регистрация</h1>

<?php if (isset($errors['common'])): ?>
    <div class="alert error"><?= $errors['common'] ?></div>
<?php endif; ?>

<form method="post" class="card form">
    <label>Логин</label>
    <input type="text" name="login" value="<?= htmlspecialchars($old['login']) ?>">
    <?php if (isset($errors['login'])): ?><span class="hint error"><?= $errors['login'] ?></span><?php endif; ?>

    <label>Пароль</label>
    <input type="password" name="password">
    <?php if (isset($errors['password'])): ?><span class="hint error"><?= $errors['password'] ?></span><?php endif; ?>

    <label>ФИО</label>
    <input type="text" name="fio" value="<?= htmlspecialchars($old['fio']) ?>">

    <label>Телефон</label>
    <input type="text" name="phone" value="<?= htmlspecialchars($old['phone']) ?>">

    <label>E-mail</label>
    <input type="text" name="email" value="<?= htmlspecialchars($old['email']) ?>">
    <?php if (isset($errors['email'])): ?><span class="hint error"><?= $errors['email'] ?></span><?php endif; ?>

    <button type="submit" class="btn">Зарегистрироваться</button>
    <a href="login.php" class="link">Уже зарегистрированы? Вход</a>
</form>
<?php include 'footer.php'; ?>
