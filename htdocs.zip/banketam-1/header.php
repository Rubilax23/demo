<?php require_once 'db.php'; ?>
<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Банкетам.Нет</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<header class="topbar">
    <div class="bar">
        <div class="logo">🍽 Банкетам.Нет</div>
        <?php if (isset($_SESSION['user_id'])): ?>
            <nav class="nav">
                <a href="cabinet.php">Кабинет</a>
                <a href="order.php">Заявка</a>
                <a href="logout.php">Выход</a>
            </nav>
        <?php elseif (isset($_SESSION['admin'])): ?>
            <nav class="nav">
                <a href="admin.php">Заявки</a>
                <a href="logout.php">Выход</a>
            </nav>
        <?php endif; ?>
    </div>
</header>
<main class="content<?= !empty($narrow) ? ' narrow' : '' ?>">
