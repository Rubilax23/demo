<?php
require_once 'db.php';
if (isset($_SESSION['user_id'])) { header('Location: cabinet.php'); exit; }
if (isset($_SESSION['admin'])) { header('Location: admin.php'); exit; }

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login = trim($_POST['login']);
    $password = $_POST['password'];

    $stmt = mysqli_prepare($conn, 'SELECT id, password, role FROM users WHERE login = ?');
    mysqli_stmt_bind_param($stmt, 's', $login);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);
    $user = mysqli_fetch_assoc($res);

    if ($user && password_verify($password, $user['password'])) {
        if ($user['role'] === 'admin') {
            $_SESSION['admin'] = true;
            header('Location: admin.php');
        } else {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['login'] = $login;
            header('Location: cabinet.php');
        }
        exit;
    } else {
        $error = 'Неправильный логин или пароль';
    }
}

$narrow = true;
include 'header.php';
?>
<h1 class="title">Вход</h1>

<?php if ($error): ?>
    <div class="alert error"><?= $error ?></div>
<?php endif; ?>

<form method="post" class="card form">
    <label>Логин</label>
    <input type="text" name="login">

    <label>Пароль</label>
    <input type="password" name="password">

    <button type="submit" class="btn">Войти</button>
    <a href="register.php" class="link">Еще не зарегистрированы? Регистрация</a>
</form>
<?php include 'footer.php'; ?>
