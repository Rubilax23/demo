<?php
require_once 'db.php';
if (!isset($_SESSION['user_id'])) { header('Location: login.php'); exit; }
$uid = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['review_order'])) {
    $oid = (int)$_POST['review_order'];
    $text = trim($_POST['review_text']);

    $stmt = mysqli_prepare($conn, 'SELECT status FROM orders WHERE id = ? AND user_id = ?');
    mysqli_stmt_bind_param($stmt, 'ii', $oid, $uid);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);
    $order = mysqli_fetch_assoc($res);

    if ($order && $order['status'] !== 'Новая' && $text !== '') {
        $stmt = mysqli_prepare($conn, 'INSERT INTO reviews (order_id, text) VALUES (?, ?)');
        mysqli_stmt_bind_param($stmt, 'is', $oid, $text);
        mysqli_stmt_execute($stmt);
    }
    header('Location: cabinet.php');
    exit;
}

$stmt = mysqli_prepare($conn, 'SELECT o.id, r.name AS room, o.banquet_date, o.payment, o.status, rv.text AS review
    FROM orders o
    JOIN rooms r ON o.room_id = r.id
    LEFT JOIN reviews rv ON rv.order_id = o.id
    WHERE o.user_id = ?
    ORDER BY o.id DESC');
mysqli_stmt_bind_param($stmt, 'i', $uid);
mysqli_stmt_execute($stmt);
$orders = mysqli_stmt_get_result($stmt);

include 'header.php';
?>
<h1 class="title">Личный кабинет</h1>

<?php if (isset($_GET['ok'])): ?>
    <div class="alert success">Заявка отправлена на согласование</div>
<?php endif; ?>

<div class="slider">
    <div class="slides">
        <img class="slide active" src="img/slide1.png" alt="Зал">
        <img class="slide" src="img/slide2.png" alt="Ресторан">
        <img class="slide" src="img/slide3.png" alt="Летняя веранда">
        <img class="slide" src="img/slide4.png" alt="Закрытая веранда">
    </div>
    <button class="prev" type="button">‹</button>
    <button class="next" type="button">›</button>
</div>

<a href="order.php" class="btn">Новая заявка</a>

<h2 class="subtitle">Мои заявки</h2>

<?php if (mysqli_num_rows($orders) === 0): ?>
    <p class="empty">Заявок пока нет</p>
<?php endif; ?>

<div class="orders">
<?php while ($o = mysqli_fetch_assoc($orders)): ?>
    <div class="card order">
        <div class="order-room"><?= htmlspecialchars($o['room']) ?></div>
        <div class="order-row">📅 <?= date('d.m.Y', strtotime($o['banquet_date'])) ?></div>
        <div class="order-row">💳 <?= htmlspecialchars($o['payment']) ?></div>
        <div class="order-row">
            <span class="status status-<?= $o['status'] === 'Новая' ? 'new' : ($o['status'] === 'Банкет завершен' ? 'done' : 'set') ?>">
                <?= $o['status'] ?>
            </span>
        </div>

        <?php if ($o['review']): ?>
            <div class="review">Ваш отзыв: <?= htmlspecialchars($o['review']) ?></div>
        <?php elseif ($o['status'] !== 'Новая'): ?>
            <form method="post" class="review-form">
                <input type="hidden" name="review_order" value="<?= $o['id'] ?>">
                <textarea name="review_text" placeholder="Оставьте отзыв об услуге"></textarea>
                <button type="submit" class="btn small">Отправить отзыв</button>
            </form>
        <?php endif; ?>
    </div>
<?php endwhile; ?>
</div>
<?php include 'footer.php'; ?>
