<?php
require_once 'db.php';
if (!isset($_SESSION['user_id'])) { header('Location: login.php'); exit; }

$payments = ['Наличные', 'Банковская карта', 'Онлайн-оплата'];
$error = '';

$rooms = [];
$res = mysqli_query($conn, 'SELECT id, name FROM rooms ORDER BY id');
while ($row = mysqli_fetch_assoc($res)) { $rooms[] = $row; }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $room_id = (int)$_POST['room_id'];
    $date = $_POST['date'];
    $payment = $_POST['payment'];

    $d = DateTime::createFromFormat('Y-m-d', $date);
    $dateOk = $d && $d->format('Y-m-d') === $date;

    if ($room_id === 0 || $date === '' || $payment === '') {
        $error = 'Заполните все поля';
    } elseif (!$dateOk) {
        $error = 'Выберите корректную дату';
    } elseif (!in_array($payment, $payments)) {
        $error = 'Выберите способ оплаты';
    } else {
        $uid = $_SESSION['user_id'];
        $status = 'Новая';
        $stmt = mysqli_prepare($conn, 'INSERT INTO orders (user_id, room_id, banquet_date, payment, status) VALUES (?, ?, ?, ?, ?)');
        mysqli_stmt_bind_param($stmt, 'iisss', $uid, $room_id, $date, $payment, $status);
        mysqli_stmt_execute($stmt);
        header('Location: cabinet.php?ok=1');
        exit;
    }
}

$narrow = true;
include 'header.php';
?>
<h1 class="title">Оформление заявки</h1>

<?php if ($error): ?>
    <div class="alert error"><?= $error ?></div>
<?php endif; ?>

<form method="post" class="card form">
    <label>Помещение</label>
    <select name="room_id">
        <option value="">— выберите —</option>
        <?php foreach ($rooms as $r): ?>
            <option value="<?= $r['id'] ?>"><?= htmlspecialchars($r['name']) ?></option>
        <?php endforeach; ?>
    </select>

    <label>Дата начала банкета</label>
    <input type="date" name="date">

    <label>Способ оплаты</label>
    <select name="payment">
        <option value="">— выберите —</option>
        <?php foreach ($payments as $p): ?>
            <option value="<?= $p ?>"><?= $p ?></option>
        <?php endforeach; ?>
    </select>

    <button type="submit" class="btn">Отправить заявку</button>
</form>
<?php include 'footer.php'; ?>
