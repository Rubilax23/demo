document.addEventListener('DOMContentLoaded', function () {
    var slider = document.querySelector('.slider');
    if (slider) {
        var slides = slider.querySelectorAll('.slide');
        var i = 0;
        function show(n) {
            slides.forEach(function (s, k) { s.classList.toggle('active', k === n); });
        }
        function next() { i = (i + 1) % slides.length; show(i); }
        function prev() { i = (i - 1 + slides.length) % slides.length; show(i); }
        function reset() { clearInterval(timer); timer = setInterval(next, 3000); }
        var timer = setInterval(next, 3000);
        slider.querySelector('.next').addEventListener('click', function () { next(); reset(); });
        slider.querySelector('.prev').addEventListener('click', function () { prev(); reset(); });
    }

    var toast = document.querySelector('.toast');
    if (toast) {
        setTimeout(function () { toast.classList.add('hide'); }, 2500);
    }
});
