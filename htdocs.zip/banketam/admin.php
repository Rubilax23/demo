<?php
require_once 'db.php';
if (!isset($_SESSION['admin'])) { header('Location: login.php'); exit; }

$statuses = ['Новая', 'Банкет назначен', 'Банкет завершен'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['order_id'])) {
    $oid = (int)$_POST['order_id'];
    $st = $_POST['status'];
    if (in_array($st, $statuses)) {
        $stmt = mysqli_prepare($conn, 'UPDATE orders SET status = ? WHERE id = ?');
        mysqli_stmt_bind_param($stmt, 'si', $st, $oid);
        mysqli_stmt_execute($stmt);
    }
    header('Location: admin.php?msg=1');
    exit;
}

$rooms = [];
$res = mysqli_query($conn, 'SELECT id, name FROM rooms ORDER BY id');
while ($row = mysqli_fetch_assoc($res)) { $rooms[] = $row; }

$filter = $_GET['status'] ?? '';
$roomFilter = (int)($_GET['room'] ?? 0);
$dateFilter = $_GET['date'] ?? '';
$sort = ($_GET['sort'] ?? 'date') === 'status' ? 'status' : 'date';
$dir = ($_GET['dir'] ?? 'desc') === 'asc' ? 'ASC' : 'DESC';
$sortCol = $sort === 'status' ? 'o.status' : 'o.banquet_date';

$conds = [];
if (in_array($filter, $statuses)) {
    $conds[] = "o.status = '" . mysqli_real_escape_string($conn, $filter) . "'";
}
if ($roomFilter > 0) {
    $conds[] = "o.room_id = $roomFilter";
}
$d = DateTime::createFromFormat('Y-m-d', $dateFilter);
if ($d && $d->format('Y-m-d') === $dateFilter) {
    $conds[] = "o.banquet_date = '" . mysqli_real_escape_string($conn, $dateFilter) . "'";
}
$where = $conds ? 'WHERE ' . implode(' AND ', $conds) : '';

$perPage = 5;
$page = max(1, (int)($_GET['page'] ?? 1));
$offset = ($page - 1) * $perPage;

$total = mysqli_fetch_row(mysqli_query($conn, "SELECT COUNT(*) FROM orders o $where"))[0];
$pages = (int)ceil($total / $perPage);

$sql = "SELECT o.id, u.fio, u.phone, r.name AS room, o.banquet_date, o.payment, o.status
    FROM orders o
    JOIN users u ON o.user_id = u.id
    JOIN rooms r ON o.room_id = r.id
    $where
    ORDER BY $sortCol $dir
    LIMIT $perPage OFFSET $offset";
$orders = mysqli_query($conn, $sql);

$qs = "&status=" . urlencode($filter) . "&room=$roomFilter&date=" . urlencode($dateFilter);

function sortLink($col, $label, $sort, $dir, $qs) {
    $newDir = ($sort === $col && $dir === 'ASC') ? 'desc' : 'asc';
    return "<a href=\"?sort=$col&dir=$newDir$qs\">$label</a>";
}

include 'header.php';
?>
<h1 class="title">Заявки</h1>

<form method="get" class="card filter">
    <div class="filter-row">
        <div class="filter-field">
            <label>Статус</label>
            <select name="status" onchange="this.form.submit()">
                <option value="">Все</option>
                <?php foreach ($statuses as $s): ?>
                    <option value="<?= $s ?>" <?= $filter === $s ? 'selected' : '' ?>><?= $s ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="filter-field">
            <label>Помещение</label>
            <select name="room" onchange="this.form.submit()">
                <option value="0">Все</option>
                <?php foreach ($rooms as $r): ?>
                    <option value="<?= $r['id'] ?>" <?= $roomFilter === (int)$r['id'] ? 'selected' : '' ?>><?= htmlspecialchars($r['name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="filter-field">
            <label>Дата</label>
            <input type="date" name="date" value="<?= htmlspecialchars($dateFilter) ?>" onchange="this.form.submit()">
        </div>
    </div>
    <a href="admin.php" class="link">Сбросить фильтры</a>
</form>

<div class="sort-bar">
    Сортировать:
    <?= sortLink('date', 'по дате', $sort, $dir, $qs) ?> ·
    <?= sortLink('status', 'по статусу', $sort, $dir, $qs) ?>
</div>

<?php if (mysqli_num_rows($orders) === 0): ?>
    <p class="empty">Заявок нет</p>
<?php endif; ?>

<div class="orders">
<?php while ($o = mysqli_fetch_assoc($orders)): ?>
    <div class="card order">
        <div class="order-room">#<?= $o['id'] ?> · <?= htmlspecialchars($o['room']) ?></div>
        <div class="order-row">👤 <?= htmlspecialchars($o['fio']) ?></div>
        <div class="order-row">📞 <?= htmlspecialchars($o['phone']) ?></div>
        <div class="order-row">📅 <?= date('d.m.Y', strtotime($o['banquet_date'])) ?></div>
        <div class="order-row">💳 <?= htmlspecialchars($o['payment']) ?></div>
        <div class="order-row">
            <span class="status status-<?= $o['status'] === 'Новая' ? 'new' : ($o['status'] === 'Банкет завершен' ? 'done' : 'set') ?>">
                <?= $o['status'] ?>
            </span>
        </div>
        <form method="post" class="status-form">
            <input type="hidden" name="order_id" value="<?= $o['id'] ?>">
            <select name="status">
                <?php foreach ($statuses as $s): ?>
                    <option value="<?= $s ?>" <?= $o['status'] === $s ? 'selected' : '' ?>><?= $s ?></option>
                <?php endforeach; ?>
            </select>
            <button type="submit" class="btn small">Сохранить</button>
        </form>
    </div>
<?php endwhile; ?>
</div>

<?php if ($pages > 1): ?>
    <div class="pagination">
        <?php for ($i = 1; $i <= $pages; $i++): ?>
            <a href="?page=<?= $i ?>&sort=<?= $sort ?>&dir=<?= strtolower($dir) ?><?= $qs ?>"
               class="<?= $i === $page ? 'active' : '' ?>"><?= $i ?></a>
        <?php endfor; ?>
    </div>
<?php endif; ?>

<?php if (isset($_GET['msg'])): ?>
    <div class="toast">Статус обновлён</div>
<?php endif; ?>
<?php include 'footer.php'; ?>
