<?php
require_once 'db.php';
if (isset($_SESSION['user_id'])) {
    header('Location: cabinet.php');
} elseif (isset($_SESSION['admin'])) {
    header('Location: admin.php');
} else {
    header('Location: login.php');
}
exit;
